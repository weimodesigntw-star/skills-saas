# Skills Management Console

Cowork Skills 管理後台 — 包含 Skills 總覽、腳本管理、QA Dashboard、文件瀏覽。

## Quick Deploy to GitHub Pages

```bash
# 1. 建立 GitHub repo
gh repo create skills-console --public --source=. --push

# 2. 啟用 GitHub Pages (Settings > Pages > Source: Deploy from branch > /docs)
#    或用 CLI:
gh api repos/{owner}/skills-console/pages -X POST -f source.branch=main -f source.path=/docs

# 3. 等待 1-2 分鐘，造訪:
#    https://{your-username}.github.io/skills-console/
```

## Structure

```
skills-site/
├── README.md
├── docs/           ← GitHub Pages root
│   └── index.html  ← 完整單頁應用 (SPA)
```

## Features

- **Overview** — 6 Skills 總覽，狀態、腳本、觸發詞
- **Skills** — 每個 Skill 詳細資訊
- **Scripts** — 所有腳本清單與分類
- **QA Dashboard** — 57 項測試結果，篩選/搜尋/模擬執行
- **Files** — 產出文件瀏覽
